import React from "react";

const Loading = () => {
  return <h1>loading</h1>;
};

export default Loading;
